## SoftwareIncTrainer

This Trainer is for Software Inc game. It's based on https://github.com/hrkrx/SoftwareIncDLLModifications by hrkrx

*NOTE: I can't guarantee that some features integrated in this trainer will work with old saves. If you want to test it out, please backup your data first.

Download Trainer.dll and put in the DLLMods folder in your Software Inc directory. If the directory does not exist, create it.

Report bugs and suggestions through Github Issues.

[Features](FEATURES.md)
[Changelog](CHANGELOG.md)
